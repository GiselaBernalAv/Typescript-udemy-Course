//let x:number = parseFloat(prompt("Enter a number"));
//console.log(x+3);
var courses = ["Angular", "React", "Express"];
console.log(courses.toString());
var mybool = false;
var x = mybool.toString();
console.log(x);
