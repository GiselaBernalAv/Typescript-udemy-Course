var num1 = 10;
var num2 = 2;
var num3 = num2;
num3 += num1;
console.log(num3);
