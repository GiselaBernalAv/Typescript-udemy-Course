var x = 40;
var y = 50;
console.log(x === 30);
console.log(x !== 30);
console.log(x < y);
