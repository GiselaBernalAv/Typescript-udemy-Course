var x:number = 8;
var y:number = 10;

console.log((x>y)?"X is greater than Y":"Y is greater than x");
