var x = 8;
var y = 10;
console.log((x > y) ? "X is greater than Y" : "Y is greater than x");
