var num1:number = 10;
var num2:number = 2;
var num3:number = num2;

num3 += num1;

console.log(num3);