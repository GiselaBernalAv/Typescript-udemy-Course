console.log("Hello");
alert("Hello");
confirm("Do you really want to do this?");
var data = prompt("Please enter you name");
console.log(data);
