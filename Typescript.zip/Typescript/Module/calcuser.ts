import Calculator ,{Calculator1} from './calc';

var calc = new Calculator();
console.log(calc.add(2,3));

console.log(calc.sub(10,5));