"use strict";
exports.__esModule = true;
var Calculator = /** @class */ (function () {
    function Calculator() {
    }
    Calculator.prototype.add = function (x, y) {
        return x + y;
    };
    Calculator.prototype.sub = function (x, y) {
        return x - y;
    };
    return Calculator;
}());
exports["default"] = Calculator;
var Calculator1 = /** @class */ (function () {
    function Calculator1() {
    }
    Calculator1.prototype.add = function (x, y) {
        return x + y;
    };
    Calculator1.prototype.sub = function (x, y) {
        return x - y;
    };
    return Calculator1;
}());
exports.Calculator1 = Calculator1;
