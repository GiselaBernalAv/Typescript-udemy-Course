const product = function(x:number,y:number):number{
    return x*y;
}


console.log(product);

